package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.UsersModel;
import com.example.demo.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	public UserService(UserRepository userRepository) {
		this.userRepository = userRepository;
	}
	
	
	public UsersModel registerUser(String login,String firstName,String lastName, String email,  long phone, String address,String password, String rpassword ) {
		if(email ==null || password ==null) {
			return null;
		}
		else {
			if(userRepository.findByEmail(email).isPresent()) {
				System.out.println("Duplicate login. \n Already registered ");
				return null;
			}
			
			UsersModel user = new UsersModel(); 
			user.setLogin(login);
			user.setPassword(password);
			user.setRpassword(rpassword);
			user.setEmail(email);
			user.setFirstName(firstName);
			user.setLastName(lastName);
			user.setPhone(phone);
			user.setAddress(address);
			return userRepository.save(user);
		}
		
	}
	
	public UsersModel authenticate(String email, String password) {
		return userRepository.findByEmailAndPassword(email, password).orElse(null);
	}


	
	
}
