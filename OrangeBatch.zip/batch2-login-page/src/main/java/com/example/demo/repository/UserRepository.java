package com.example.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.UsersModel;

public interface UserRepository extends JpaRepository<UsersModel,Integer> {

	Optional<UsersModel> findByEmail(String email);

	Optional<UsersModel> findByEmailAndPassword(String email, String password);

}
