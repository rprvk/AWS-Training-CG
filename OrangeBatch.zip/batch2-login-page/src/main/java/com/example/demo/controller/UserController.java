package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.UsersModel;
import com.example.demo.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@GetMapping("/")
	public String home() {
		return "NewFile";
	}
	
	
	@GetMapping("/register")
	public String getRegisterPage(Model model) {
		model.addAttribute("registerRequest", new UsersModel());
		return "register_page";
	}
	
	@GetMapping("/login")
	public String getLoginPage(Model model) {
		model.addAttribute("loginRequest", new UsersModel());
		return "login_page";
	}
	
	@PostMapping("/register")
	public String register(@ModelAttribute UsersModel usersModel) {
		System.out.println("register request"+ usersModel);
		UsersModel registeredUser = userService.registerUser(usersModel.getLogin(),usersModel.getFirstName(),usersModel.getLastName(),
				usersModel.getEmail(),usersModel.getPhone(),usersModel.getAddress(),usersModel.getPassword(),usersModel.getRpassword());
		return registeredUser == null ? "error_Page" : "redirect:/login";
	}

	@PostMapping("/login")
	public String login(@ModelAttribute UsersModel usersModel, Model model) {
		System.out.println("login request"+ usersModel);
		UsersModel authenticated = userService.authenticate(usersModel.getEmail(),usersModel.getPassword());
		if(authenticated != null) {
			model.addAttribute("userLogin", authenticated.getFirstName());
			model.addAttribute("userId", authenticated.getLogin());
			model.addAttribute("userFName", authenticated.getFirstName());
			model.addAttribute("userLName", authenticated.getLastName());
			model.addAttribute("userEmail", authenticated.getEmail());
			model.addAttribute("userPhone", authenticated.getPhone());
			model.addAttribute("userAddress", authenticated.getAddress());
			return "personal_page";
		}else {
			return "error_page";
		}
	}  
}

/**
 * 
 * /
 */